		<div id="footer">
			<div id="footer_menu">
				<ul>
					<li><a href="#login_box"  data-toggle="modal">MY ACCOUNT</a></li>
					<li><a href="#">INFORMATION</a></li>
					<li><a href="#">CUSTOMER SERVICE</a></li>
					<li><a href="#">EXTRAS</a></li>
				</ul>	
			</div>	
			<div id="copyright">
				Beyond Pink | Unique Women Clothing &copy 2013.
			</div>	
		</div>