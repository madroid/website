		<div id="top">
			<div id="logo" class="logo">
					<a href="home2.php"><img src="../layout/logo.png" alt="BeyondPink Logo"/></a>
				</div>
				<div id="menu" class="menu">
					<ul>	
						<li><a href="category.php?tag=Women">Women</a></li>.
						<li class="dropdown"><a href="category.php?tag=Bottom">Bottom</a>
							<ul class="sub_menu">
								<li><a href="category.php?tag=Pant">Pant</a></li>
								<li><a href="category.php?tag=Shorts">Shorts</a></li>
								<li><a href="category.php?tag=Skirts">Skirts</a></li>
							</ul>	
						</li>.
						<li><a href="category.php?tag=Jumpsuite">Jumpsuite</a></li>.
						<li><a href="category.php?tag=Footwear">Footwear</a></li>.
						<li><a href="category.php?tag=Bellerinas">Bellerinas</a></li>.
						<li class="dropdown"><a href="category.php?tag=Winter%20%Wear">Winter Wear</a>
							<ul class="sub_menu">
								<li><a href="category.php?tag=Cardigan">Cardigan</a></li>
								<li><a href="category.php?tag=Jacket">Jacket</a></li>
								<li><a href="category.php?tag=Sweater">Sweater</a></li>
							</ul>	
						</li>.
						<li><a href="#">Special Requests</a></li>.
					</ul>
				</div>
			</div>
