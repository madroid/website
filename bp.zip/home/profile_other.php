		<div id="profile_header">
			<div id="profile_header1">
				<span class="profile_header"><span style="font-size:20px">]</span> PROFILE <span style="font-size:20px">[</span></span>
				<span class="profile_header">HOME</span>
			</div>	
		</div>	

		<div id="profile_tabs">
			<div id="tabs">
				<span class="tabs_element">Wardrobe</span>
				<span class="tabs_element">Uploads</span>
				<span class="tabs_element">Favourites</span>
			</div>	
		</div>	
