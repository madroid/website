<meta charset="utf-8">
<title>BeyondPink | Unique Women Clothing</title>
<link href="../css/bootstrap.css" rel="stylesheet">
<link href="../css/bootstrap-responsive.css" rel="stylesheet">
<link href="../css/common.css" rel="stylesheet">
<script src="../js/jquery.min.js"></script>
<script src="../js/common.js"></script>
<script src="../js/login.js"></script>
<script type="text/javascript" src="../js/bootstrap.js"></script>    
