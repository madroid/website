<?php

require_once('common.php');

$query = "SELECT * FROM home";
echo execute_query($query);



?>