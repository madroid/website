<?php

define('DB_USER', "sagar"); // db user
define('DB_PASSWORD', "1234"); // db password (mention your db password here)
define('DB_DATABASE', "bpink"); // database name
define('DB_SERVER', "localhost"); // db server
?>