window.onload = initProfilePage ;

function initProfilePage(){
	
}