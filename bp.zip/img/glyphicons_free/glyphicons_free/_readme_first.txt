-------------------------------------------
THANK YOU FOR USING GLYPHICONS
-------------------------------------------
If you would like to be among the first ones to hear about all the news, follow @GLYPHICONS on Twitter.


-------------------------------------------
LICENSE
-------------------------------------------
GLYPHICONS FREE are released under the Creative Commons Attribution 3.0 Unported (CC BY 3.0). The GLYPHICONS FREE can be used both commercially and for personal use, but you must always add a link to GLYPHICONS.com in a prominent place (e.g. the footer of a website), include the CC-BY license and the reference to GLYPHICONS.com on every page using icons.

All icons are provided "as they are" without a warranty of any kind, either expressed or implied. I am not liable for any damages coused of any defects in this icon set. All logos and trademarks in social icons are the property of the respective trademark owners.®


-------------------------------------------
LICENSE FOR HALFLINGS IN TWITTER BOOTSTRAP
-------------------------------------------
GLYPHICONS Halflings are also a part of Bootstrap from Twitter, and they are released under the same license as Bootstrap. While you are not required to include attribution on your Bootstrap-based projects, I would certainly appreciate a visible link back to GLYPHICONS.com in any place you find appropriate (footer, docs, etc).


-------------------------------------------
CONTACT
-------------------------------------------
Web: http://glyphicons.com/
Email: glyphicons@gmail.com
Twitter: http://twitter.com/glyphicons


-------------------------------------------
NOTE
-------------------------------------------
If you want to use the icons without restrictions, please buy any version on www.glyphicons.com, thank you.

Jan Kovařík